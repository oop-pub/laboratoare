package strategies;

import entities.Monster;

public interface Strategy {
    void attack(Monster m);
}
