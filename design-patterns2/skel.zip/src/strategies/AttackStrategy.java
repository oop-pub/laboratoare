package strategies;

import entities.Monster;

public class AttackStrategy implements Strategy {

	//TODO Implement constructor with a Hero as argument
	@Override
	public void attack(Monster m) {
	    // TODO implement me

	    /*	Attack algorithm
			if hero type weapon found use it (x3 weapon damage)
				else if counter weapon found use it (x2 weapon damage)
				else basic attack (no bonus)
			--> In order to find the weapon, iterate through the inventory of the hero.
	    */
	}

}
